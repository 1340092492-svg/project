import argparse
import copy
from collections import Counter
from pathlib import Path
import sys

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from character.all_character_class import AllCharacter
from config import LOG_FOLDER
from environment.action_history_class import Action, ActionHistory
from environment.all_resource_class import AllResource
from logger_class import Logger
from prompt.gpt_structure import generate_with_response_parser


DEFAULT_SCENARIO = "succession"
DEFAULT_TARGET_CHARACTER = "C0001"
DEFAULT_MAX_MEMORY = 8


def parse_args():
    parser = argparse.ArgumentParser(description="Run the memory retrieval experiment with optional LLM evaluation.")
    parser.add_argument("--scenario", default=DEFAULT_SCENARIO, help="Scenario folder under storage/")
    parser.add_argument("--target-character", default=DEFAULT_TARGET_CHARACTER, help="Target character id")
    parser.add_argument("--max-memory", type=int, default=DEFAULT_MAX_MEMORY, help="Maximum number of memories")
    parser.add_argument(
        "--engine",
        default="",
        help="Optional model engine. Examples: openai, openai:gpt-4o-mini, glm-4, gpt4, human",
    )
    parser.add_argument(
        "--with-llm",
        action="store_true",
        help="Enable LLM-based context evaluation. Requires --engine unless using a local model name.",
    )
    return parser.parse_args()


def build_synthetic_history(target_character):
    history = ActionHistory()

    critical_events = [
        ("C0000", target_character, "### MEET", "[CRITICAL] Logan privately discloses board pressure.", 0),
        ("C0002", target_character, "### CHAT_SUMMARIZATION", "[CRITICAL] Kendall signals willingness to form a coalition.", 1),
        ("C0003", target_character, "### SPEECH_NORMAL", "[CRITICAL] Shiv publicly questions the current succession plan.", 2),
        ("C0004", target_character, "### MEET", "[CRITICAL] Roman offers temporary support in exchange for future votes.", 3),
        ("C0005", target_character, "### CHAT_SUMMARIZATION", "[CRITICAL] External banker links debt refinancing to leadership stability.", 4),
        ("C0006", target_character, "### SPEECH_VOTE", "[CRITICAL] Connor announces he may abstain unless promised influence.", 5),
    ]

    filler_events = [
        ("C0000", "C0007", "### SPEECH_NORMAL", "Logan repeats a dominance statement.", 5),
        ("C0000", "C0007", "### SPEECH_NORMAL", "Logan repeats a dominance statement again.", 5),
        ("C0000", "C0007", "### SPEECH_NORMAL", "Logan repeats a dominance statement for the third time.", 5),
        ("C0000", "C0007", "### SPEECH_NORMAL", "Logan repeats a dominance statement for the fourth time.", 5),
        ("C0000", "C0007", "### SPEECH_NORMAL", "Logan repeats a dominance statement for the fifth time.", 5),
        ("C0000", "C0007", "### SPEECH_NORMAL", "Logan repeats a dominance statement for the sixth time.", 5),
        ("C0000", "C0007", "### SPEECH_NORMAL", "Logan repeats a dominance statement for the seventh time.", 5),
        ("C0000", "C0007", "### SPEECH_NORMAL", "Logan repeats a dominance statement for the eighth time.", 5),
        ("C0000", "C0007", "### SPEECH_NORMAL", "Logan repeats a dominance statement for the ninth time.", 5),
        ("C0000", "C0007", "### SPEECH_NORMAL", "Logan repeats a dominance statement for the tenth time.", 5),
    ]

    ordered_events = []
    for idx, critical in enumerate(critical_events):
        ordered_events.append(critical)
        if idx < 2:
            ordered_events.append(("C0007", "C0008", "### SPEECH_NORMAL", "A side character adds low-value commentary.", idx))
    ordered_events.extend(filler_events)

    for action_id, (source, target, action_type, action_text, happen_time) in enumerate(ordered_events):
        history.insert_action(Action(action_id, source, target, action_type, action_text, happen_time))
    return history


def load_scenario_context(scenario_name, target_character):
    base_dir = ROOT_DIR / "storage" / scenario_name / "initial_version"
    characters = AllCharacter(str(base_dir / "characters"))
    resources = AllResource(str(base_dir / "resources"))
    basic_setting_path = base_dir / "basic_setting.json"
    if basic_setting_path.exists():
        import json

        basic_setting = json.loads(basic_setting_path.read_text(encoding="utf-8"))
        rule_path = ROOT_DIR / basic_setting["rule_setting"].lstrip("./")
        rule_setting = rule_path.read_text(encoding="utf-8") if rule_path.exists() else ""
    else:
        rule_setting = ""
    character = characters.get_character_by_id(target_character)
    return {
        "character": character,
        "character_description": character.get_self_description() if character.get_id_number() else "",
        "all_characters_description": characters.get_characters_description_except_some([target_character]),
        "resources_description": resources.get_description(),
        "rule_setting": rule_setting,
    }


def evaluate_selection(actions, target_character):
    critical_total = sum(1 for action in actions if "[CRITICAL]" in action.action)
    unique_speakers = len({action.source_character_id_number for action in actions})
    unique_rounds = len({action.happen_time for action in actions})
    self_related = sum(
        1 for action in actions
        if target_character in [action.source_character_id_number, action.to_character_id_number]
    )
    type_counter = Counter(action.action_type for action in actions)
    return {
        "critical_hits": critical_total,
        "speaker_count": unique_speakers,
        "round_count": unique_rounds,
        "self_related_ratio": self_related / len(actions) if actions else 0.0,
        "speech_share": (
            (type_counter["### SPEECH_NORMAL"] + type_counter["### SPEECH_VOTE"]) / len(actions)
            if actions else 0.0
        ),
    }


def print_retrieval_report(label, actions, target_character):
    metrics = evaluate_selection(actions, target_character)
    print(f"{label} strategy")
    print(f"selected_ids: {[action.id for action in actions]}")
    print(f"selected_speakers: {[action.source_character_id_number for action in actions]}")
    print(f"critical_hits: {metrics['critical_hits']}")
    print(f"speaker_count: {metrics['speaker_count']}")
    print(f"round_count: {metrics['round_count']}")
    print(f"self_related_ratio: {metrics['self_related_ratio']:.3f}")
    print(f"speech_share: {metrics['speech_share']:.3f}")
    print()


def build_context_payload(history, strategy, target_character, max_memory):
    selected_actions = history.select_visible_actions(
        character_id_number=target_character,
        max_num=max_memory,
        strategy=strategy,
    )
    context_text = history.get_description(
        character_id_number=target_character,
        max_num=max_memory,
        strategy=strategy,
    )
    return selected_actions, context_text


def parse_llm_eval(output_text):
    result = {}
    lines = [line.strip() for line in output_text.splitlines() if line.strip()]
    prefixes = {
        "### Context Score:": "context_score",
        "### Alliance Target:": "alliance_target",
        "### Key Fact Count:": "key_fact_count",
        "### Decision Consistency:": "decision_consistency",
        "### Summary:": "summary",
    }
    for line in lines:
        for prefix, key in prefixes.items():
            if line.startswith(prefix):
                result[key] = line[len(prefix):].strip()
    if len(result) != len(prefixes):
        raise Exception("[Error]: LLM evaluation parse error")
    return result


def evaluate_with_llm(label, context_text, scenario_context, engine, logger):
    prompt = f"""
You are evaluating memory quality for a multi-agent role-playing system.

### Evaluation Goal
Assess whether the provided memory context gives enough high-value information for the target character to make a coherent next-step decision.

### Rule Setting
{scenario_context['rule_setting']}

### Target Character Description
{scenario_context['character_description']}

### Other Character Overview
{scenario_context['all_characters_description']}

### Resource Overview
{scenario_context['resources_description']}

### Memory Strategy
{label}

### Candidate Memory Context
{context_text}

Please output exactly in the following format:
### Context Score: <0-100 integer>
### Alliance Target: <character id or NONE>
### Key Fact Count: <integer>
### Decision Consistency: <0-1 float>
### Summary: <one sentence>
""".strip()

    return generate_with_response_parser(
        prompt,
        gpt_param={"temperature": 0, "top_p": 1, "stream": False, "max_tokens": 300},
        parser_fn=parse_llm_eval,
        engine=engine,
        logger=logger,
        func_name=f"memory_eval_{label}",
    )


def evaluate_pairwise_with_llm(recent_context, hybrid_context, scenario_context, engine, logger):
    prompt = f"""
You are comparing two memory retrieval strategies for a multi-agent social simulation.

### Rule Setting
{scenario_context['rule_setting']}

### Target Character Description
{scenario_context['character_description']}

### Recent Context
{recent_context}

### Hybrid Context
{hybrid_context}

Choose the context that better supports a coherent strategic decision for the target character.

Please output exactly in the following format:
### Better Strategy: <recent or hybrid>
### Margin: <0-100 integer>
### Reason: <one sentence>
""".strip()

    def parser_fn(output_text):
        result = {}
        lines = [line.strip() for line in output_text.splitlines() if line.strip()]
        prefixes = {
            "### Better Strategy:": "better_strategy",
            "### Margin:": "margin",
            "### Reason:": "reason",
        }
        for line in lines:
            for prefix, key in prefixes.items():
                if line.startswith(prefix):
                    result[key] = line[len(prefix):].strip()
        if len(result) != len(prefixes):
            raise Exception("[Error]: Pairwise evaluation parse error")
        return result

    return generate_with_response_parser(
        prompt,
        gpt_param={"temperature": 0, "top_p": 1, "stream": False, "max_tokens": 200},
        parser_fn=parser_fn,
        engine=engine,
        logger=logger,
        func_name="memory_eval_pairwise",
    )


def run_llm_evaluation(recent_context, hybrid_context, scenario_context, engine):
    log_dir = str(ROOT_DIR / LOG_FOLDER.lstrip("./"))
    logger = Logger(log_dir)
    recent_eval = evaluate_with_llm("recent", recent_context, scenario_context, engine, logger)
    hybrid_eval = evaluate_with_llm("hybrid", hybrid_context, scenario_context, engine, logger)
    pairwise_eval = evaluate_pairwise_with_llm(recent_context, hybrid_context, scenario_context, engine, logger)
    return {
        "recent": recent_eval,
        "hybrid": hybrid_eval,
        "pairwise": pairwise_eval,
    }


def print_llm_report(llm_result):
    print("LLM context evaluation")
    for label in ["recent", "hybrid"]:
        item = llm_result[label]
        print(f"{label}_context_score: {item['context_score']}")
        print(f"{label}_alliance_target: {item['alliance_target']}")
        print(f"{label}_key_fact_count: {item['key_fact_count']}")
        print(f"{label}_decision_consistency: {item['decision_consistency']}")
        print(f"{label}_summary: {item['summary']}")
        print()
    print(f"pairwise_better_strategy: {llm_result['pairwise']['better_strategy']}")
    print(f"pairwise_margin: {llm_result['pairwise']['margin']}")
    print(f"pairwise_reason: {llm_result['pairwise']['reason']}")
    print()


def main():
    args = parse_args()
    scenario_context = load_scenario_context(args.scenario, args.target_character)
    history = build_synthetic_history(args.target_character)
    recent_actions, recent_context = build_context_payload(
        history,
        "recent",
        args.target_character,
        args.max_memory,
    )
    hybrid_actions, hybrid_context = build_context_payload(
        history,
        "hybrid",
        args.target_character,
        args.max_memory,
    )

    print("Memory Retrieval Comparison")
    print(f"scenario: {args.scenario}")
    print(f"target_character: {args.target_character}")
    print(f"max_memory: {args.max_memory}")
    print()
    print_retrieval_report("recent", recent_actions, args.target_character)
    print_retrieval_report("hybrid", hybrid_actions, args.target_character)

    if args.with_llm:
        if not args.engine:
            raise ValueError("--with-llm requires --engine")
        llm_result = run_llm_evaluation(recent_context, hybrid_context, scenario_context, args.engine)
        print_llm_report(llm_result)


if __name__ == "__main__":
    main()
